import React, { useState } from 'react';

const Contact = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [contacts, setContacts] = useState([]);
  const [newContact, setNewContact] = useState('');

  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handleNewContactChange = (event) => {
    setNewContact(event.target.value);
  };

  const addContact = () => {
    if (name && email && newContact) {
      // Create a new contact object
      const contact = {
        name: name,
        email: email,
        contactNumber: newContact,
      };

      // Add the new contact to the contacts array
      setContacts([...contacts, contact]);

      // Clear input fields
      setName('');
      setEmail('');
      setNewContact('');
    } else {
      alert('Please enter name, email, and contact number.');
    }
  };

  return (
    <div>
      <h2>Contact Information</h2>
      <div>
        <label>Name:</label>
        <input type="text" value={name} onChange={handleNameChange} />
      </div>
      <div>
        <label>Email:</label>
        <input type="email" value={email} onChange={handleEmailChange} />
      </div>
      <div>
        <label>Contact Number:</label>
        <input type="text" value={newContact} onChange={handleNewContactChange} />
      </div>
      <button onClick={addContact}>Add Contact</button>

      <h2>Contacts List</h2>
      <ul>
        {contacts.map((contact, index) => (
          <li key={index}>
            <strong>Name:</strong> {contact.name}, <strong>Email:</strong> {contact.email}, <strong>Contact Number:</strong> {contact.contactNumber}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Contact;
