import React from "react";
export default function Footer(){
    return (
        <div className="Footer">
            <p>Copyright GAT 2024</p>
        </div>
    )
}