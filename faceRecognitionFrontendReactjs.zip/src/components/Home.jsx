import React from "react";
import bimg from "./Face.webp"

export default function Home() {
    return (
        <div id="home">
            <div className="left">
                <h3>Welcome to <span>Face Recognition Attendance System</span></h3>
                <p>Automate Attendance with Facial Recognition</p>
            </div>
            <div className="right">
                <img src={bimg} alt="Recognition_image"/>
            </div>
        </div>
    )
}