import React from "react";
import bimg from "./Img2.jpg"

export default function About() {
    return (
        <div id="about"><br/><br/>
            <h3>About the System</h3>
            <p>A face recognition-based attendance system is a 
                technology that uses facial recognition algorithms
                 to identify individuals and record their attendance. 
                 It works by capturing an image or video of an individual's face, 
                 analyzing the facial features and comparing them with the existing database of faces
                  to determine if there is a match. </p>
                  <div className="center">
                <img src={bimg} alt="Recognition2_image"/>
            </div>            
        </div>
    )
}