import React, { useEffect, useRef, useState } from 'react';

const FaceRecognitionSystem = () => {
  const videoRef = useRef(null);
  const startButtonRef = useRef(null);
  const stopButtonRef = useRef(null);
  const messageRef = useRef(null);

  useEffect(() => {
    const initializeCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        videoRef.current.srcObject = stream;
      } catch (error) {
        messageRef.current.innerHTML = 'Failed to access camera. Please check your camera settings.';
      }
    };

    initializeCamera();
  }, []);

  const handleStartClick = () => {
    startButtonRef.current.disabled = true;
    stopButtonRef.current.disabled = false;
    messageRef.current.innerHTML = 'Face recognition started';
  };

  const handleStopClick = () => {
    startButtonRef.current.disabled = false;
    stopButtonRef.current.disabled = true;
    messageRef.current.innerHTML = 'Face recognition stopped';
  };

  return (
    <div className="container">
      <h1><center>Face Recognition Attendance System</center></h1>
      <div className="video-container">
        <video id="video" width="400" height="400" autoPlay muted ref={videoRef}></video>
      </div>
      <div className="btn-container">
        <button id="start" onClick={handleStartClick} ref={startButtonRef} aria-label="Start Face Recognition">
          Start
        </button>
        <button id="stop" onClick={handleStopClick} ref={stopButtonRef} aria-label="Stop Face Recognition">
          Stop
        </button>
      </div>
      <p id="message" ref={messageRef}></p>
    </div>
  );
};

export default FaceRecognitionSystem;
