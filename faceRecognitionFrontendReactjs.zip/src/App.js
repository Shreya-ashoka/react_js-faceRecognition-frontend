import React, { useState } from "react";
import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/Home';
import About from './components/About';
import Features from './components/Features';
import Contact from './components/Contact';
import FaceRecognitionSystem from './components/FaceRecognitionSystem';

function App() {
  const menuItems = ["Home", "About", "Features", "FaceRecognitionSystem", "Contact"];
  const [activeMenuItem, setActiveMenuItem] = useState(menuItems[0]);

  const handleMenuItemClick = (menuItem) => {
    setActiveMenuItem(menuItem);
  };

  // Component mapping
  const components = {
    Home: <Home />,
    About: <About />,
    Features: <Features />,
    FaceRecognitionSystem: <FaceRecognitionSystem />,
    Contact: <Contact />,
  };

  return (
    <div className="App">
      <Header menuItems={menuItems} activeMenuItem={activeMenuItem} onMenuItemClick={handleMenuItemClick} />
      <div className="container">
        {components[activeMenuItem]}
      </div>
      <Footer />
    </div>
  );
}

export default App;
