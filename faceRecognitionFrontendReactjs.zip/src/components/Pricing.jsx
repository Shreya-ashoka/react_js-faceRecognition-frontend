import React from "react";
export default function Pricing() {
    return (
        <div id="pricing">
            <h3>PRICING COMPARISION</h3>
            <table>
                <thead>
                    <tr>
                        <th>Feature</th>
                        <th>Plan</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Hourly meetings</td>
                        <td>Basic</td>
                        <td>Rs.2000/-</td>
                    </tr>
                    <tr>
                        <td>Minutes of meetings</td>
                        <td>Standard</td>
                        <td>Rs.4000/-</td>
                    </tr>
                    <tr>
                        <td>Single Point of Contact</td>
                        <td>Premium`</td>
                        <td>Rs.20000/-</td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}