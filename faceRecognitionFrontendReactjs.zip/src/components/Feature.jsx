import React from "react";

export default function Feature({ feature }) {
    return (
        <div className="Feature">
            <h3>{feature.name}</h3>
            <p>{feature.desc}</p>
        </div>
    );
}
