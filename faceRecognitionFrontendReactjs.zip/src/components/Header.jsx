import React from "react";

export default function Header({ menuItems, activeMenuItem, onMenuItemClick }) {
  return (
    <div className="Header">
      <h2 onClick={() => onMenuItemClick(menuItems[0])}>Face Recognition</h2>
      <menu>
        {menuItems.map((menuItem) => (
          <li
            key={menuItem}
            className={activeMenuItem === menuItem ? "active" : ""}
            onClick={() => onMenuItemClick(menuItem)}
          >
            {menuItem}
          </li>
        ))}
      </menu>
    </div>
  );
}
