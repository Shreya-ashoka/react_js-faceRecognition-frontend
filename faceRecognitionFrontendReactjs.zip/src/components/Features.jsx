import React from "react";
import Feature from "./Feature";

export default function Features() {
    const featuresList = [
        {
            id: 0,
            name: "Facial Detection",
            desc: "Visual Identity Verification"
        },
        {
            id: 1,
            name: "Facial Recognition",
            desc: "Identity Authentication System"
        },
        {
            id: 2,
            name: "Automated Attendance Tracking",
            desc: "Effortless Attendance Management"
        },
        {
            id: 3,
            name: "Data Management",
            desc: "Efficient Data Handling"
        },
        {
            id: 4,
            name: "Accuracy",
            desc: "High Precision Recognition"
        },
        {
            id: 5,
            name: "Scalability",
            desc: "Easily Expandable System"
        },
        {
            id: 6,
            name: "User-friendly Interface",
            desc: "Intuitive User Experience"
        },
        {
            id: 7,
            name: "Security",
            desc: "Robust Access Protection"
        },
        {
            id: 8,
            name: "Flexibility",
            desc: "Adaptable Configuration Options"
        },
        {
            id: 9,
            name: "Real-time Monitoring",
            desc: "Live Activity Observation"
        },
        {
            id: 10,
            name: "Real-Time Notifications",
            desc: "Instant Alert Delivery"
        },
        {
            id: 11,
            name: "Easy User Management",
            desc: "Simplified User Administration"
        }
    ];
    

    return (
        <div id="Features">
            {featuresList.map((feature) => (
                <Feature key={feature.id} feature={feature} />
            ))}
        </div>
    );
}
